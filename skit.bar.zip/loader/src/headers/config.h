#pragma once

#define HTTP_SERVER "146.59.86.30"
#define HTTP_PORT 80

#define TFTP_SERVER "146.59.86.30"
