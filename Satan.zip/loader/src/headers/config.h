#pragma once

#define HTTP_SERVER "172.31.43.143"
#define HTTP_PORT 80

#define TFTP_SERVER "172.31.43.143"
